<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('office_addresses', function (Blueprint $table) {
                $table->id();
                $table->text('address');
                $table->text('addressName');
                $table->string('town');
                $table->string('phone');
                $table->text('description');
                $table->string('lat');
                $table->string('lang');
                $table->foreignId('officeId')->references('id')->on('offices')->onDelete('cascade');
                $table->timestamps();
            });
       
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('office_addresses');
    }
};
