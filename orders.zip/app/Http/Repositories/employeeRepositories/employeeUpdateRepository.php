<?php
namespace App\Http\Repositories\employeeRepositories;
use App\Http\Core\Repositories\Abstract_CRUD_Repositoris\UpdateRepository;
use App\Models\employee;

class employeeUpdateRepository extends UpdateRepository
{
    public function __construct()
    {
        $this->model = new employee();
    }

}