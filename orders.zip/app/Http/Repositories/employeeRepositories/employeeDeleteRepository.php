<?php
namespace App\Http\Repositories\employeeRepositories;
use App\Http\Core\Repositories\Abstract_CRUD_Repositoris\DeleteRepository;
use App\Models\employee;

class employeeDeleteRepository extends DeleteRepository
{
    public function __construct()
    {
        $this->model = new employee();
    }
}