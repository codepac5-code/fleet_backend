<?php
namespace App\Http\Repositories\employeeRepositories;
use App\Models\{employee};

class employeeRepositoryCaller{

    static public function createRepository(){return (new employeeCreateRepository());}
    static public function readRepository(){return (new employeeReadRepository());}
    static public function updateRepository(){return (new employeeUpdateRepository());}
    static public function deleteRepository(){return (new employeeDeleteRepository());}
    static public function get_model() : employee {return (new employee());}


}