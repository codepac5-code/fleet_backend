<?php
namespace App\Http\Repositories\employeeRepositories;
use App\Http\Core\Repositories\Abstract_CRUD_Repositoris\ReadRepository;
use App\Models\employee;

class employeeReadRepository extends ReadRepository
{
    public function __construct()
    {
        $this->model = new employee();
    }

}