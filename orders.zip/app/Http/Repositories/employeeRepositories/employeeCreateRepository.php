<?php
namespace App\Http\Repositories\employeeRepositories;
use App\Http\Core\Repositories\Abstract_CRUD_Repositoris\CreateRepository;
use App\Models\employee;

class employeeCreateRepository extends CreateRepository
{
    public function __construct()
    {
        $this->model = new employee();
    }
}